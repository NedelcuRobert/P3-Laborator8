#include "caine.h"

class CCaineFaraPete:public CCaine
{
public:
	void citire_caine();
	void afisare_caine();
};

