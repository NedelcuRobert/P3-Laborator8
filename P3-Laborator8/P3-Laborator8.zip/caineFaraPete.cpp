#include "caineFaraPete.h"

void CCaineFaraPete::citire_caine() {
	CCaine::citire_caine();
}

void CCaineFaraPete::afisare_caine() {
	CCaine::afisare_caine();
}
