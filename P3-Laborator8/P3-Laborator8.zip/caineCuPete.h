#include "caineFaraPete.h"

class CCaineCuPete:public CCaine
{
private:
	int numar_pete;
public:
	void citire_caine();
	void afisare_caine();
};

